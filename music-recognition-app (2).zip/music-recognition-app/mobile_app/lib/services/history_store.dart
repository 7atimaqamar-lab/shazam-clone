import '../models/recognition_result.dart';

/// Very small in-memory session history. Swap for local persistence
/// (e.g. sqflite/shared_preferences) or a backend-side history
/// endpoint if you want it to survive app restarts.
class HistoryStore {
  HistoryStore._internal();
  static final HistoryStore instance = HistoryStore._internal();

  final List<RecognitionResult> _items = [];

  List<RecognitionResult> get items => List.unmodifiable(_items);

  void add(RecognitionResult result) {
    _items.insert(0, result);
  }

  void clear() {
    _items.clear();
  }
}
