import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/recognition_result.dart';
import '../models/track.dart';

/// All network calls to the FastAPI backend live here, so screens
/// never talk to `http` directly.
class ApiService {
  // Point this at your deployed backend (see infra/docker-compose.yml).
  final String baseUrl;

  ApiService({this.baseUrl = 'https://api.your-domain.com'});

  /// Sends a recorded audio clip to POST /recognize and returns the match.
  Future<RecognitionResult> recognize(String audioFilePath) async {
    try {
      final uri = Uri.parse('$baseUrl/recognize');
      final request = http.MultipartRequest('POST', uri)
        ..files.add(await http.MultipartFile.fromPath('audio', audioFilePath));

      final streamed = await request.send().timeout(const Duration(seconds: 15));
      final response = await http.Response.fromStream(streamed);

      if (response.statusCode == 200) {
        return RecognitionResult.fromJson(jsonDecode(response.body));
      }
      return RecognitionResult.noMatch();
    } catch (_) {
      // Network error, timeout, or backend unreachable.
      return RecognitionResult.noMatch();
    }
  }

  /// Fetches the current regional library from GET /library
  Future<List<Track>> fetchLibrary() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/library'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        return data.map((t) => Track.fromJson(t)).toList();
      }
    } catch (_) {}
    return [];
  }

  /// Adds a new fingerprinted clip to the library via POST /library
  Future<bool> addTrack(String audioFilePath, String name, String artist) async {
    try {
      final uri = Uri.parse('$baseUrl/library');
      final request = http.MultipartRequest('POST', uri)
        ..fields['name'] = name
        ..fields['artist'] = artist
        ..files.add(await http.MultipartFile.fromPath('audio', audioFilePath));

      final streamed = await request.send().timeout(const Duration(seconds: 15));
      return streamed.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
