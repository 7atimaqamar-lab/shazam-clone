import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/root_nav.dart';

void main() {
  runApp(const SurApp());
}

class SurApp extends StatelessWidget {
  const SurApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sur',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const RootNav(),
    );
  }
}
