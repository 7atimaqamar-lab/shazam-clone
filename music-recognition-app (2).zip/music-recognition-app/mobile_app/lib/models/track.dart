/// Represents a song in the regional library (or the user's own added clip).
class Track {
  final String id;
  final String name;
  final String artist;
  final String icon;
  final String source; // "local_regional_library" | "commercial_fallback" | "user_added"

  const Track({
    required this.id,
    required this.name,
    required this.artist,
    this.icon = '\u266A',
    this.source = 'local_regional_library',
  });

  factory Track.fromJson(Map<String, dynamic> json) {
    return Track(
      id: json['id'].toString(),
      name: json['name'] ?? json['title'] ?? 'Unknown',
      artist: json['artist'] ?? '',
      icon: json['icon'] ?? '\u266A',
      source: json['source'] ?? 'local_regional_library',
    );
  }
}
