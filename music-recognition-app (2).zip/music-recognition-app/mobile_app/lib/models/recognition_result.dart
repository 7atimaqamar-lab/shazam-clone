/// The response shape returned by the backend's /recognize endpoint.
class RecognitionResult {
  final bool matched;
  final String title;
  final String artist;
  final double confidence; // 0.0 - 1.0
  final String source;
  final DateTime timestamp;

  RecognitionResult({
    required this.matched,
    this.title = '',
    this.artist = '',
    this.confidence = 0.0,
    this.source = '',
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  factory RecognitionResult.fromJson(Map<String, dynamic> json) {
    return RecognitionResult(
      matched: json['matched'] == true,
      title: json['title'] ?? '',
      artist: json['artist'] ?? '',
      confidence: (json['confidence'] ?? 0.0).toDouble(),
      source: json['source'] ?? '',
    );
  }

  factory RecognitionResult.noMatch() => RecognitionResult(matched: false);
}
