import 'package:flutter/material.dart';

/// Central color + theme definitions so every screen stays visually
/// consistent with the "Sur" brand (dark UI, green signal accent,
/// marigold secondary accent for regional flavor).
class AppColors {
  static const bg = Color(0xFF0A0E12);
  static const surface = Color(0xFF121821);
  static const surface2 = Color(0xFF1B242F);
  static const line = Color(0xFF232E3A);
  static const accent = Color(0xFF00E6A8);
  static const accentDark = Color(0xFF00A87A);
  static const accent2 = Color(0xFFF2A65A);
  static const text = Color(0xFFEAF0F4);
  static const muted = Color(0xFF7C8B99);
  static const danger = Color(0xFFE8735A);
}

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bg,
      primaryColor: AppColors.accent,
      fontFamily: 'Roboto',
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent,
        secondary: AppColors.accent2,
        surface: AppColors.surface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bg,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: AppColors.text,
          fontSize: 20,
          fontWeight: FontWeight.w800,
        ),
        iconTheme: IconThemeData(color: AppColors.text),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.accent,
        unselectedItemColor: AppColors.muted,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
      ),
      cardColor: AppColors.surface,
      dividerColor: AppColors.line,
      textTheme: const TextTheme(
        titleLarge: TextStyle(
            color: AppColors.text, fontWeight: FontWeight.w800, fontSize: 20),
        titleMedium: TextStyle(
            color: AppColors.text, fontWeight: FontWeight.w700, fontSize: 15),
        bodyMedium: TextStyle(color: AppColors.text, fontSize: 13.5),
        bodySmall: TextStyle(color: AppColors.muted, fontSize: 12),
      ),
    );
  }
}
