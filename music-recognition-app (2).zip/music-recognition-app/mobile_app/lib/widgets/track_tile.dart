import 'package:flutter/material.dart';
import '../models/track.dart';
import '../theme/app_theme.dart';

/// A single card in the library grid: icon, name, artist, play button.
class TrackTile extends StatelessWidget {
  final Track track;
  final VoidCallback? onPlay;
  final bool isPlaying;

  const TrackTile({
    super.key,
    required this.track,
    this.onPlay,
    this.isPlaying = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.line),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.surface2,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Text(track.icon, style: const TextStyle(fontSize: 16)),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  track.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Text(
                  track.artist,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onPlay,
            child: Container(
              width: 30,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isPlaying ? AppColors.accent : Colors.transparent,
                border: Border.all(
                  color: isPlaying ? AppColors.accent : AppColors.line,
                ),
              ),
              child: Icon(
                Icons.play_arrow,
                size: 16,
                color: isPlaying ? const Color(0xFF052019) : AppColors.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
