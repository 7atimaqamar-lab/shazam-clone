import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// The central "tap to listen" button with expanding sonar rings while
/// actively recording. Purely presentational — the parent screen owns
/// the recording state and passes `isListening` in.
class SonarButton extends StatefulWidget {
  final bool isListening;
  final VoidCallback onTap;

  const SonarButton({
    super.key,
    required this.isListening,
    required this.onTap,
  });

  @override
  State<SonarButton> createState() => _SonarButtonState();
}

class _SonarButtonState extends State<SonarButton>
    with TickerProviderStateMixin {
  late final List<AnimationController> _ringControllers;

  @override
  void initState() {
    super.initState();
    _ringControllers = List.generate(3, (i) {
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 2200),
      );
      Future.delayed(Duration(milliseconds: i * 700), () {
        if (mounted && widget.isListening) controller.repeat();
      });
      return controller;
    });
  }

  @override
  void didUpdateWidget(covariant SonarButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isListening && !oldWidget.isListening) {
      for (final c in _ringControllers) {
        c.repeat();
      }
    } else if (!widget.isListening && oldWidget.isListening) {
      for (final c in _ringControllers) {
        c.stop();
        c.reset();
      }
    }
  }

  @override
  void dispose() {
    for (final c in _ringControllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      height: 200,
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (widget.isListening)
            ..._ringControllers.map((controller) {
              return AnimatedBuilder(
                animation: controller,
                builder: (context, child) {
                  final t = controller.value;
                  final size = 70 + (110 * t);
                  return Opacity(
                    opacity: (1 - t).clamp(0, 1),
                    child: Container(
                      width: size,
                      height: size,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.accent, width: 1.5),
                      ),
                    ),
                  );
                },
              );
            }),
          GestureDetector(
            onTap: widget.onTap,
            child: Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.accent, AppColors.accentDark],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.35),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Icon(
                widget.isListening ? Icons.graphic_eq : Icons.mic,
                color: const Color(0xFF052019),
                size: 34,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
