import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// A labeled progress bar showing match confidence, used on the
/// result screen. Animates from 0 to the target percentage.
class ConfidenceMeter extends StatelessWidget {
  final double confidence; // 0.0 - 1.0

  const ConfidenceMeter({super.key, required this.confidence});

  @override
  Widget build(BuildContext context) {
    final pct = (confidence * 100).clamp(0, 99).round();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Match confidence', style: Theme.of(context).textTheme.bodySmall),
            Text('$pct%', style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(100),
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: confidence.clamp(0, 1)),
            duration: const Duration(milliseconds: 600),
            builder: (context, value, _) {
              return LinearProgressIndicator(
                value: value,
                minHeight: 6,
                backgroundColor: AppColors.surface2,
                valueColor: const AlwaysStoppedAnimation(AppColors.accent),
              );
            },
          ),
        ),
      ],
    );
  }
}
