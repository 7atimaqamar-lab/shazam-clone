import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/sonar_button.dart';
import '../services/api_service.dart';
import '../services/audio_recorder_service.dart';
import '../services/history_store.dart';
import '../models/recognition_result.dart';
import 'result_screen.dart';

class ListenScreen extends StatefulWidget {
  const ListenScreen({super.key});

  @override
  State<ListenScreen> createState() => _ListenScreenState();
}

class _ListenScreenState extends State<ListenScreen> {
  final ApiService _api = ApiService();
  final AudioRecorderService _recorder = AudioRecorderService();

  bool _isListening = false;
  String _status = 'Tap to listen';
  String? _error;

  static const _recordSeconds = 4;

  Future<void> _handleTap() async {
    if (_isListening) return;

    setState(() {
      _isListening = true;
      _status = 'Listening…';
      _error = null;
    });

    try {
      await _recorder.start();
      await Future.delayed(const Duration(seconds: _recordSeconds));
      final path = await _recorder.stop();

      setState(() => _status = 'Matching…');

      final RecognitionResult result = path != null
          ? await _api.recognize(path)
          : RecognitionResult.noMatch();

      HistoryStore.instance.add(result);

      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ResultScreen(result: result)),
      );
    } catch (e) {
      setState(() => _error =
          'Microphone unavailable or permission denied. Check app settings and try again.');
    } finally {
      if (mounted) {
        setState(() {
          _isListening = false;
          _status = 'Tap to listen';
        });
      }
    }
  }

  @override
  void dispose() {
    _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sur')),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SonarButton(isListening: _isListening, onTap: _handleTap),
            const SizedBox(height: 22),
            Text(
              _status,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(
              _error ??
                  'Records a few seconds of audio and checks it against the '
                      'regional library first, then a fallback service.',
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .bodySmall
                  ?.copyWith(color: _error != null ? AppColors.danger : AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}
