import 'package:flutter/material.dart';
import '../models/recognition_result.dart';
import '../theme/app_theme.dart';
import '../widgets/confidence_meter.dart';
import 'library_screen.dart';

class ResultScreen extends StatelessWidget {
  final RecognitionResult result;
  const ResultScreen({super.key, required this.result});

  String get _sourceLabel {
    switch (result.source) {
      case 'local_regional_library':
        return 'Local Regional Library';
      case 'commercial_fallback':
        return 'Fallback API';
      default:
        return 'Unknown source';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Result')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: result.matched ? _buildMatch(context) : _buildNoMatch(context),
      ),
    );
  }

  Widget _buildMatch(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 58,
              height: 58,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [AppColors.accent2, Color(0xFFC97A2E)],
                ),
              ),
              child: const Text('\u266A', style: TextStyle(fontSize: 22)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(result.title, style: Theme.of(context).textTheme.titleLarge),
                  Text(result.artist, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          children: [
            Chip(
              label: Text(_sourceLabel),
              backgroundColor: AppColors.surface2,
              side: const BorderSide(color: AppColors.accent),
              labelStyle: const TextStyle(color: AppColors.accent, fontSize: 11),
            ),
          ],
        ),
        const SizedBox(height: 18),
        ConfidenceMeter(confidence: result.confidence),
        const SizedBox(height: 24),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Listen again'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildNoMatch(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.search_off, color: AppColors.danger, size: 36),
        const SizedBox(height: 12),
        Text('No match found', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text(
          'This clip isn\'t in the regional library or the fallback service. '
          'You can add it to the library so it\'s recognized next time.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const LibraryScreen(startInAddMode: true)),
                  );
                },
                child: const Text('Add to library'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Try again'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
