import 'package:flutter/material.dart';
import '../models/track.dart';
import '../services/api_service.dart';
import '../services/audio_recorder_service.dart';
import '../theme/app_theme.dart';
import '../widgets/track_tile.dart';

class LibraryScreen extends StatefulWidget {
  final bool startInAddMode;
  const LibraryScreen({super.key, this.startInAddMode = false});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final ApiService _api = ApiService();
  final AudioRecorderService _recorder = AudioRecorderService();

  List<Track> _tracks = [];
  bool _loading = true;
  String? _playingId;

  @override
  void initState() {
    super.initState();
    _load();
    if (widget.startInAddMode) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _openAddDialog());
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final tracks = await _api.fetchLibrary();
    setState(() {
      _tracks = tracks;
      _loading = false;
    });
  }

  Future<void> _openAddDialog() async {
    final nameController = TextEditingController();
    final artistController = TextEditingController();
    bool isRecording = false;
    String? recordedPath;

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: AppColors.surface,
              title: const Text('Add a song to the library'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Song title'),
                  ),
                  TextField(
                    controller: artistController,
                    decoration: const InputDecoration(labelText: 'Artist'),
                  ),
                  const SizedBox(height: 14),
                  ElevatedButton.icon(
                    icon: Icon(isRecording ? Icons.stop : Icons.mic),
                    label: Text(isRecording
                        ? 'Stop (recording…)'
                        : recordedPath != null
                            ? 'Re-record clip'
                            : 'Record ~10s clip'),
                    onPressed: () async {
                      if (!isRecording) {
                        await _recorder.start();
                        setDialogState(() => isRecording = true);
                      } else {
                        final path = await _recorder.stop();
                        setDialogState(() {
                          isRecording = false;
                          recordedPath = path;
                        });
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: recordedPath == null || nameController.text.trim().isEmpty
                      ? null
                      : () async {
                          final ok = await _api.addTrack(
                            recordedPath!,
                            nameController.text.trim(),
                            artistController.text.trim(),
                          );
                          if (context.mounted) Navigator.pop(context);
                          if (ok) _load();
                        },
                  child: const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Regional Library'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: _openAddDialog),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
          : _tracks.isEmpty
              ? Center(
                  child: Text('No songs yet — add the first one.',
                      style: Theme.of(context).textTheme.bodySmall),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _tracks.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final t = _tracks[i];
                      return TrackTile(
                        track: t,
                        isPlaying: _playingId == t.id,
                        onPlay: () => setState(
                            () => _playingId = _playingId == t.id ? null : t.id),
                      );
                    },
                  ),
                ),
    );
  }
}
