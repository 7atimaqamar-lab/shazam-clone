# Sur — Music Recognition App

Full-stack skeleton matching the Technology Selection Report:
Flutter frontend, FastAPI backend, Dejavu (local) + commercial API (fallback)
fingerprinting, PostgreSQL + Redis storage.

## Structure

```
music-recognition-app/
├── mobile_app/       Flutter app (lib/screens, lib/widgets, lib/services)
├── backend/          FastAPI app (app/routes, app/fingerprint, app/fallback)
├── database/         Postgres schema + Redis config
└── infra/            docker-compose.yml to run backend + db locally
```

## Running locally

1. `cd infra && docker compose up --build` — starts Postgres, Redis, backend on :8000
2. `cd mobile_app && flutter run` — starts the Flutter app (point `ApiService.baseUrl` at your backend)
3. Set `AUDD_API_KEY` as an environment variable for fallback recognition

## Next steps

- Install PyDejavu and wire up `dejavu_engine.py` against the Postgres instance
- Seed the regional library by fingerprinting real audio files via `add_song_to_library`
- Add mic recording in Flutter with the `record` package (already in `pubspec.yaml`)
