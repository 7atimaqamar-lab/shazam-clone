"""
Wraps the Dejavu landmark-hashing fingerprint library.
Real setup: `pip install PyDejavu` and configure it to point at the
Postgres database defined in database/postgres/schema.sql.
"""

from typing import TypedDict


class MatchResult(TypedDict):
    matched: bool
    title: str
    artist: str
    confidence: float


def match_local(audio_bytes: bytes) -> MatchResult:
    # djv = Dejavu(config)  # config loaded from environment / settings
    # song = djv.recognize(FileRecognizer, tmp_audio_path)
    #
    # if song and song["confidence"] > THRESHOLD:
    #     return {"matched": True, "title": song["song_name"], ...}

    return {"matched": False, "title": "", "artist": "", "confidence": 0.0}


def add_song_to_library(audio_path: str, title: str, artist: str) -> None:
    """Fingerprints a new track and stores it in the local Postgres index."""
    # djv.fingerprint_file(audio_path, song_name=title)
    pass
