"""
Fallback recognition via a paid API, used only when the local
regional library (Dejavu) doesn't find a match. Keeps cost down since
this is called for the minority of lookups.
"""

import os
import requests

AUDD_API_KEY = os.getenv("AUDD_API_KEY", "")
AUDD_ENDPOINT = "https://api.audd.io/"


def match_fallback(audio_bytes: bytes) -> dict:
    if not AUDD_API_KEY:
        return {"matched": False}

    response = requests.post(
        AUDD_ENDPOINT,
        data={"api_token": AUDD_API_KEY, "return": "apple_music,spotify"},
        files={"file": audio_bytes},
        timeout=10,
    )
    data = response.json()

    result = data.get("result")
    if not result:
        return {"matched": False}

    return {
        "matched": True,
        "title": result.get("title", ""),
        "artist": result.get("artist", ""),
        "confidence": 0.9,
    }
