from fastapi import FastAPI
from app.routes import recognize, library

app = FastAPI(title="Sur Recognition API")

app.include_router(recognize.router, prefix="/recognize", tags=["recognize"])
app.include_router(library.router, prefix="/library", tags=["library"])


@app.get("/health")
def health():
    return {"status": "ok"}
