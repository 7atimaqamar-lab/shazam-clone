from fastapi import APIRouter, UploadFile, File, Form
from app.fingerprint.dejavu_engine import add_song_to_library

router = APIRouter()

# In production this reads/writes the `songs` table in Postgres.
# Stubbed here with an in-memory list so the API is runnable end-to-end.
_LIBRARY = [
    {"id": "t1", "name": "Barish Ki Raat", "artist": "Regional", "icon": "\u2614", "source": "local_regional_library"},
    {"id": "t2", "name": "Sur Milaa Lo", "artist": "Regional", "icon": "\U0001F3B6", "source": "local_regional_library"},
]


@router.get("/")
def list_library():
    return _LIBRARY


@router.post("/")
async def add_track(audio: UploadFile = File(...), name: str = Form(...), artist: str = Form("")):
    audio_bytes = await audio.read()

    # Fingerprint the clip and store it against the Postgres index.
    add_song_to_library(audio_path=audio.filename, title=name, artist=artist)

    new_id = f"u{len(_LIBRARY) + 1}"
    _LIBRARY.append({"id": new_id, "name": name, "artist": artist or "Added by you", "icon": "\u2795", "source": "user_added"})
    return {"ok": True, "id": new_id}
