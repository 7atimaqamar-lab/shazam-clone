from fastapi import APIRouter, UploadFile, File
from app.fingerprint.dejavu_engine import match_local
from app.fallback.commercial_api import match_fallback

router = APIRouter()


@router.post("/")
async def recognize(audio: UploadFile = File(...)):
    audio_bytes = await audio.read()

    # 1. Try the local regional fingerprint database first (Dejavu)
    local_result = match_local(audio_bytes)
    if local_result["matched"]:
        return {
            "matched": True,
            "title": local_result["title"],
            "artist": local_result["artist"],
            "confidence": local_result["confidence"],
            "source": "local_regional_library",
        }

    # 2. Fall back to a commercial API (ACRCloud / AudD) for global coverage
    fallback_result = match_fallback(audio_bytes)
    if fallback_result["matched"]:
        return {
            "matched": True,
            "title": fallback_result["title"],
            "artist": fallback_result["artist"],
            "confidence": fallback_result["confidence"],
            "source": "commercial_fallback",
        }

    return {"matched": False}
