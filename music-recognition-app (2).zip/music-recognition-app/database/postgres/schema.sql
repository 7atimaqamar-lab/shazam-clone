-- Songs table: one row per track in the regional library
CREATE TABLE songs (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    artist TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Fingerprints table: Dejavu-style landmark hashes
CREATE TABLE fingerprints (
    id BIGSERIAL PRIMARY KEY,
    song_id INTEGER REFERENCES songs(id) ON DELETE CASCADE,
    hash BYTEA NOT NULL,
    offset_ms INTEGER NOT NULL
);

CREATE INDEX idx_fingerprints_hash ON fingerprints (hash);
